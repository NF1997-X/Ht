# Horizontal Scroll Containers Mobile & Desktop - Spotify Style

A Pen created on CodePen.

Original URL: [https://codepen.io/kilianso/pen/XQOGXX](https://codepen.io/kilianso/pen/XQOGXX).

Horizontal overflow scrolling cards in Spotify style that work on desktop and mobile.